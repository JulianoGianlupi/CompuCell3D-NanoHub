% MEX binding of IDAS functions
%
%-- Radu Serban @ LLNL -- April 2005
